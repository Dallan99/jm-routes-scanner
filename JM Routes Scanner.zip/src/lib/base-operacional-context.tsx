import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

export type BaseSelecionada = {
  id: string;
  codigo: string;
  nome: string;
  cidade: string | null;
};

type BaseOperacionalState = {
  base: BaseSelecionada | null;
  diaOperacional: string | null; // YYYY-MM-DD
  setSelecao: (base: BaseSelecionada, dia: string) => void;
  limpar: () => void;
};

const CTX = createContext<BaseOperacionalState | null>(null);

const STORAGE_KEY = "jm.baseOperacional";

export function BaseOperacionalProvider({ children }: { children: ReactNode }) {
  const [base, setBase] = useState<BaseSelecionada | null>(null);
  const [diaOperacional, setDia] = useState<string | null>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return;
      const s = JSON.parse(raw) as { base: BaseSelecionada; diaOperacional: string };
      if (s?.base?.id && s?.diaOperacional) {
        setBase(s.base);
        setDia(s.diaOperacional);
      }
    } catch {
      /* ignore */
    }
  }, []);

  const value = useMemo<BaseOperacionalState>(
    () => ({
      base,
      diaOperacional,
      setSelecao: (b, d) => {
        setBase(b);
        setDia(d);
        try {
          localStorage.setItem(STORAGE_KEY, JSON.stringify({ base: b, diaOperacional: d }));
        } catch {
          /* ignore */
        }
      },
      limpar: () => {
        setBase(null);
        setDia(null);
        try {
          localStorage.removeItem(STORAGE_KEY);
        } catch {
          /* ignore */
        }
      },
    }),
    [base, diaOperacional],
  );

  return <CTX.Provider value={value}>{children}</CTX.Provider>;
}

export function useBaseOperacional() {
  const ctx = useContext(CTX);
  if (!ctx) throw new Error("useBaseOperacional deve ser usado dentro de BaseOperacionalProvider");
  return ctx;
}
